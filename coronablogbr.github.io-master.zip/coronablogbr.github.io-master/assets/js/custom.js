$(document).ready(function() {
/*
  $("ul.nav li a").each(function() {
    if ($(this).attr('href') == location.pathname) {
      $(this).parent().addClass("active");
    }
  });
*/
});
